# Android Bluetooth HID keyboard

Native Android wrapper for the existing smartphone keyboard UI.

## What it does

- locked landscape orientation;
- true immersive fullscreen / edge-to-edge;
- draws into display cutout areas (`LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS` on Android 11+);
- requests system gesture exclusion in all four corners;
- keeps the screen awake while the keyboard is open;
- uses the existing HTML-style keyboard UI inside a local WebView;
- registers Android as a Bluetooth HID keyboard (API 28+);
- remembers the last selected paired computer and reconnects on the next launch.

## Pairing

1. Install and launch the APK.
2. Grant **Nearby devices** permissions if Android asks.
3. Tap **PAIR NEW COMPUTER** in the setup overlay.
4. On Windows open **Settings → Bluetooth & devices → Add device → Bluetooth** and select the phone.
5. Confirm the pairing dialog on both devices.
6. Back in the app, tap the computer in the paired devices list once. The app remembers it for later launches.

The setup overlay disappears when the HID connection is established.

## Build

Open the `android` directory as a project in Android Studio, or run:

```bash
gradle :app:assembleDebug
```

The repository GitHub Actions workflow also builds a debug APK artifact automatically.
