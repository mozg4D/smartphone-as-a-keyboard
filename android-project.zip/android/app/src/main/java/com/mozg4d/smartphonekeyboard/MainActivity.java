package com.mozg4d.smartphonekeyboard;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 1001;
    private static final String PREFS = "smartphone_keyboard";
    private static final String PREF_LAST_HOST = "last_host";

    private static final byte[] KEYBOARD_REPORT_DESCRIPTOR = new byte[] {
            0x05, 0x01,                    // Usage Page (Generic Desktop)
            0x09, 0x06,                    // Usage (Keyboard)
            (byte) 0xA1, 0x01,             // Collection (Application)
            0x05, 0x07,                    // Usage Page (Keyboard/Keypad)
            0x19, (byte) 0xE0,             // Usage Minimum (Keyboard Left Control)
            0x29, (byte) 0xE7,             // Usage Maximum (Keyboard Right GUI)
            0x15, 0x00,                    // Logical Minimum (0)
            0x25, 0x01,                    // Logical Maximum (1)
            0x75, 0x01,                    // Report Size (1)
            (byte) 0x95, 0x08,             // Report Count (8)
            (byte) 0x81, 0x02,             // Input (Data,Var,Abs) - modifiers
            (byte) 0x95, 0x01,             // Report Count (1)
            0x75, 0x08,                    // Report Size (8)
            (byte) 0x81, 0x01,             // Input (Const) - reserved byte
            (byte) 0x95, 0x05,             // Report Count (5)
            0x75, 0x01,                    // Report Size (1)
            0x05, 0x08,                    // Usage Page (LEDs)
            0x19, 0x01,                    // Usage Minimum (Num Lock)
            0x29, 0x05,                    // Usage Maximum (Kana)
            (byte) 0x91, 0x02,             // Output (Data,Var,Abs)
            (byte) 0x95, 0x01,             // Report Count (1)
            0x75, 0x03,                    // Report Size (3)
            (byte) 0x91, 0x01,             // Output (Const)
            (byte) 0x95, 0x06,             // Report Count (6)
            0x75, 0x08,                    // Report Size (8)
            0x15, 0x00,                    // Logical Minimum (0)
            0x25, 0x65,                    // Logical Maximum (101)
            0x05, 0x07,                    // Usage Page (Keyboard/Keypad)
            0x19, 0x00,                    // Usage Minimum (Reserved)
            0x29, 0x65,                    // Usage Maximum (Keyboard Application)
            (byte) 0x81, 0x00,             // Input (Data,Array)
            (byte) 0xC0                    // End Collection
    };

    private final ExecutorService hidExecutor = Executors.newSingleThreadExecutor();
    private final Object reportLock = new Object();
    private final LinkedHashSet<Integer> pressedUsages = new LinkedHashSet<>();
    private final Set<String> syntheticShiftTokens = new LinkedHashSet<>();

    private WebView webView;
    private boolean pageReady;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothHidDevice hidDevice;
    private BluetoothDevice connectedHost;
    private boolean hidRegistered;
    private String pendingHostAddress;
    private String bluetoothMessage = "Starting Bluetooth…";

    private boolean ctrlDown;
    private boolean shiftDown;
    private boolean altDown;
    private boolean guiDown;

    private final BluetoothProfile.ServiceListener profileListener = new BluetoothProfile.ServiceListener() {
        @Override
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            if (profile != BluetoothProfile.HID_DEVICE) return;
            hidDevice = (BluetoothHidDevice) proxy;
            bluetoothMessage = "Bluetooth HID ready";
            registerHidApp();
            notifyWebState();
        }

        @Override
        public void onServiceDisconnected(int profile) {
            if (profile != BluetoothProfile.HID_DEVICE) return;
            hidDevice = null;
            hidRegistered = false;
            connectedHost = null;
            bluetoothMessage = "Bluetooth HID service disconnected";
            clearPressedKeys(false);
            notifyWebState();
        }
    };

    private final BluetoothHidDevice.Callback hidCallback = new BluetoothHidDevice.Callback() {
        @Override
        public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean registered) {
            hidRegistered = registered;
            if (!registered) {
                connectedHost = null;
                bluetoothMessage = "HID registration stopped";
                clearPressedKeys(false);
            } else {
                bluetoothMessage = "HID registered";
                if (pluggedDevice != null) {
                    connectedHost = pluggedDevice;
                }
                String target = pendingHostAddress;
                pendingHostAddress = null;
                if (target == null) {
                    target = getPreferences(MODE_PRIVATE).getString(PREF_LAST_HOST, null);
                }
                if (target != null) connectToAddress(target);
            }
            notifyWebState();
        }

        @Override
        public void onConnectionStateChanged(BluetoothDevice device, int state) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                connectedHost = device;
                bluetoothMessage = "Connected to " + safeDeviceName(device);
                try {
                    getPreferences(MODE_PRIVATE).edit().putString(PREF_LAST_HOST, device.getAddress()).apply();
                } catch (SecurityException ignored) {
                }
                sendCurrentReport();
            } else if (state == BluetoothProfile.STATE_CONNECTING) {
                bluetoothMessage = "Connecting to " + safeDeviceName(device) + "…";
            } else if (state == BluetoothProfile.STATE_DISCONNECTING) {
                bluetoothMessage = "Disconnecting…";
            } else {
                if (connectedHost != null && connectedHost.equals(device)) connectedHost = null;
                bluetoothMessage = "Not connected";
                clearPressedKeys(false);
            }
            notifyWebState();
        }

        @Override
        public void onGetReport(BluetoothDevice device, byte type, byte id, int bufferSize) {
            if (hidDevice == null || !hasBluetoothConnectPermission()) return;
            if (type == BluetoothHidDevice.REPORT_TYPE_INPUT) {
                hidDevice.replyReport(device, type, id, buildReport());
            } else {
                hidDevice.reportError(device, BluetoothHidDevice.ERROR_RSP_INVALID_RPT_ID);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        configureCutoutAndImmersiveMode();
        createKeyboardWebView();
        ensureBluetoothPermissionsAndStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        configureCutoutAndImmersiveMode();
        if (hasBluetoothPermissions() && bluetoothAdapter != null && hidDevice != null && !hidRegistered) {
            registerHidApp();
        }
    }

    @Override
    protected void onPause() {
        clearPressedKeys(true);
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) configureCutoutAndImmersiveMode();
    }

    @Override
    protected void onDestroy() {
        clearPressedKeys(true);
        if (hidDevice != null && hasBluetoothConnectPermission()) {
            try {
                hidDevice.unregisterApp();
            } catch (RuntimeException ignored) {
            }
        }
        if (bluetoothAdapter != null && hidDevice != null) {
            bluetoothAdapter.closeProfileProxy(BluetoothProfile.HID_DEVICE, hidDevice);
        }
        hidExecutor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_BLUETOOTH_PERMISSIONS) return;
        if (hasBluetoothPermissions()) {
            startBluetooth();
        } else {
            bluetoothMessage = "Nearby devices permission is required for Bluetooth HID";
            notifyWebState();
        }
    }

    private void configureCutoutAndImmersiveMode() {
        Window window = getWindow();
        View decor = window.getDecorView();
        WindowManager.LayoutParams lp = window.getAttributes();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            window.setAttributes(lp);
            window.setDecorFitsSystemWindows(false);

            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(lp);
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            );
        }
    }

    private void createKeyboardWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setHapticFeedbackEnabled(false);
        webView.setLongClickable(false);
        webView.setOnLongClickListener(v -> true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(true);

        webView.addJavascriptInterface(new KeyboardBridge(), "AndroidKeyboard");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                notifyWebState();
            }
        });

        setContentView(webView);
        installCornerGestureExclusion();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void installCornerGestureExclusion() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return;

        webView.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            int width = v.getWidth();
            int height = v.getHeight();
            if (width <= 0 || height <= 0) return;

            float density = getResources().getDisplayMetrics().density;
            int edgeWidth = Math.min(width / 4, Math.round(96f * density));
            int cornerHeight = Math.min(height / 3, Math.round(96f * density));

            List<Rect> exclusions = new ArrayList<>(4);
            exclusions.add(new Rect(0, 0, edgeWidth, cornerHeight));
            exclusions.add(new Rect(0, height - cornerHeight, edgeWidth, height));
            exclusions.add(new Rect(width - edgeWidth, 0, width, cornerHeight));
            exclusions.add(new Rect(width - edgeWidth, height - cornerHeight, width, height));
            v.setSystemGestureExclusionRects(exclusions);
        });
    }

    private void ensureBluetoothPermissionsAndStart() {
        if (hasBluetoothPermissions()) {
            startBluetooth();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[] {
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE
            }, REQUEST_BLUETOOTH_PERMISSIONS);
        }
    }

    private boolean hasBluetoothPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasBluetoothConnectPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void startBluetooth() {
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        bluetoothAdapter = manager == null ? null : manager.getAdapter();
        if (bluetoothAdapter == null) {
            bluetoothMessage = "This device has no Bluetooth adapter";
            notifyWebState();
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            bluetoothMessage = "Bluetooth is off";
            notifyWebState();
            return;
        }

        bluetoothMessage = "Opening Bluetooth HID profile…";
        boolean requested = bluetoothAdapter.getProfileProxy(this, profileListener, BluetoothProfile.HID_DEVICE);
        if (!requested) bluetoothMessage = "Bluetooth HID profile is unavailable";
        notifyWebState();
    }

    private void registerHidApp() {
        if (hidDevice == null || !hasBluetoothConnectPermission()) return;
        if (hidRegistered) return;

        BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings(
                "Smartphone Keyboard",
                "Touchscreen Bluetooth keyboard",
                "mozg4D",
                BluetoothHidDevice.SUBCLASS1_KEYBOARD,
                KEYBOARD_REPORT_DESCRIPTOR
        );

        try {
            boolean requested = hidDevice.registerApp(sdp, null, null, hidExecutor, hidCallback);
            bluetoothMessage = requested ? "Registering Bluetooth keyboard…" : "Bluetooth HID registration failed";
        } catch (SecurityException e) {
            bluetoothMessage = "Bluetooth permission denied";
        } catch (RuntimeException e) {
            bluetoothMessage = "Bluetooth HID error: " + e.getClass().getSimpleName();
        }
    }

    private void connectToAddress(String address) {
        if (address == null || address.isEmpty()) return;
        if (!hasBluetoothConnectPermission()) {
            bluetoothMessage = "Nearby devices permission is required";
            notifyWebState();
            return;
        }
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            bluetoothMessage = "Bluetooth is off";
            notifyWebState();
            return;
        }
        if (hidDevice == null || !hidRegistered) {
            pendingHostAddress = address;
            bluetoothMessage = "Waiting for HID registration…";
            if (hidDevice != null) registerHidApp();
            notifyWebState();
            return;
        }

        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
            if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                bluetoothMessage = "Pair the computer first";
                notifyWebState();
                return;
            }
            pendingHostAddress = null;
            bluetoothMessage = "Connecting to " + safeDeviceName(device) + "…";
            getPreferences(MODE_PRIVATE).edit().putString(PREF_LAST_HOST, address).apply();
            hidDevice.connect(device);
        } catch (IllegalArgumentException e) {
            bluetoothMessage = "Invalid Bluetooth device address";
        } catch (SecurityException e) {
            bluetoothMessage = "Bluetooth permission denied";
        }
        notifyWebState();
    }

    private void makeDiscoverable() {
        runOnUiThread(() -> {
            if (!hasBluetoothPermissions()) {
                ensureBluetoothPermissionsAndStart();
                return;
            }
            if (bluetoothAdapter == null) startBluetooth();
            if (bluetoothAdapter == null) return;

            try {
                if (!bluetoothAdapter.isEnabled()) {
                    startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                    bluetoothMessage = "Turn Bluetooth on, then tap Pair again";
                } else {
                    Intent discoverable = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    discoverable.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
                    startActivity(discoverable);
                    bluetoothMessage = "Discoverable for up to 5 minutes — add this phone from Windows Bluetooth settings";
                }
            } catch (SecurityException e) {
                bluetoothMessage = "Bluetooth permission denied";
            }
            notifyWebState();
        });
    }

    private void openBluetoothSettings() {
        runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
    }

    private String bondedDevicesJson() {
        JSONArray array = new JSONArray();
        if (!hasBluetoothConnectPermission() || bluetoothAdapter == null) return array.toString();

        try {
            Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();
            for (BluetoothDevice device : bonded) {
                JSONObject obj = new JSONObject();
                obj.put("name", safeDeviceName(device));
                obj.put("address", device.getAddress());
                array.put(obj);
            }
        } catch (SecurityException | JSONException ignored) {
        }
        return array.toString();
    }

    private String stateJson() {
        JSONObject state = new JSONObject();
        try {
            state.put("permission", hasBluetoothPermissions());
            state.put("bluetoothAvailable", bluetoothAdapter != null);
            state.put("bluetoothEnabled", bluetoothAdapter != null && bluetoothAdapter.isEnabled());
            state.put("hidAvailable", hidDevice != null);
            state.put("registered", hidRegistered);
            state.put("connected", connectedHost != null);
            state.put("message", bluetoothMessage);
            state.put("deviceName", connectedHost == null ? "" : safeDeviceName(connectedHost));
            state.put("deviceAddress", connectedHost == null ? "" : safeDeviceAddress(connectedHost));
        } catch (JSONException ignored) {
        }
        return state.toString();
    }

    private void notifyWebState() {
        if (webView == null || !pageReady) return;
        final String payload = JSONObject.quote(stateJson());
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript("window.onAndroidState && window.onAndroidState(" + payload + ");", null);
            }
        });
    }

    private String safeDeviceName(BluetoothDevice device) {
        if (device == null) return "computer";
        if (!hasBluetoothConnectPermission()) return "computer";
        try {
            String name = device.getName();
            return (name == null || name.isBlank()) ? device.getAddress() : name;
        } catch (SecurityException e) {
            return "computer";
        }
    }

    private String safeDeviceAddress(BluetoothDevice device) {
        if (device == null || !hasBluetoothConnectPermission()) return "";
        try {
            return device.getAddress();
        } catch (SecurityException e) {
            return "";
        }
    }

    private void keyDown(String token) {
        if (token == null || token.isEmpty()) return;
        synchronized (reportLock) {
            boolean syntheticShift = token.endsWith("s");
            String base = syntheticShift ? token.substring(0, token.length() - 1) : token;
            int vk = parseHexByte(base);
            if (vk < 0) return;

            if (syntheticShift) syntheticShiftTokens.add(token);
            if (setModifier(vk, true)) {
                sendCurrentReportLocked();
                return;
            }

            int usage = vkToHidUsage(vk);
            if (usage <= 0) return;
            if (pressedUsages.size() < 6 || pressedUsages.contains(usage)) {
                pressedUsages.add(usage);
                sendCurrentReportLocked();
            }
        }
    }

    private void keyUp(String token) {
        if (token == null || token.isEmpty()) return;
        synchronized (reportLock) {
            boolean syntheticShift = token.endsWith("s");
            String base = syntheticShift ? token.substring(0, token.length() - 1) : token;
            int vk = parseHexByte(base);
            if (vk < 0) return;

            if (setModifier(vk, false)) {
                sendCurrentReportLocked();
                return;
            }

            int usage = vkToHidUsage(vk);
            if (usage > 0) pressedUsages.remove(usage);
            if (syntheticShift) syntheticShiftTokens.remove(token);
            sendCurrentReportLocked();
        }
    }

    private int parseHexByte(String value) {
        if (value == null || value.length() != 2) return -1;
        try {
            return Integer.parseInt(value, 16);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private boolean setModifier(int vk, boolean down) {
        switch (vk) {
            case 0x11:
                ctrlDown = down;
                return true;
            case 0x10:
                shiftDown = down;
                return true;
            case 0x12:
                altDown = down;
                return true;
            case 0x5B:
                guiDown = down;
                return true;
            default:
                return false;
        }
    }

    private int modifierByte() {
        int result = 0;
        if (ctrlDown) result |= 0x01;
        if (shiftDown || !syntheticShiftTokens.isEmpty()) result |= 0x02;
        if (altDown) result |= 0x04;
        if (guiDown) result |= 0x08;
        return result;
    }

    private int vkToHidUsage(int vk) {
        if (vk >= 0x41 && vk <= 0x5A) return 0x04 + (vk - 0x41);       // A-Z
        if (vk >= 0x31 && vk <= 0x39) return 0x1E + (vk - 0x31);       // 1-9
        if (vk == 0x30) return 0x27;                                   // 0
        if (vk >= 0x70 && vk <= 0x7B) return 0x3A + (vk - 0x70);       // F1-F12

        switch (vk) {
            case 0x0D: return 0x28; // Enter
            case 0x1B: return 0x29; // Escape
            case 0x08: return 0x2A; // Backspace
            case 0x09: return 0x2B; // Tab
            case 0x20: return 0x2C; // Space
            case 0xBD: return 0x2D; // - _
            case 0xBB: return 0x2E; // = +
            case 0xDB: return 0x2F; // [ {
            case 0xDD: return 0x30; // ] }
            case 0xDC: return 0x31; // \\ |
            case 0xBA: return 0x33; // ; :
            case 0xDE: return 0x34; // ' "
            case 0xC0: return 0x35; // ` ~
            case 0xBC: return 0x36; // , <
            case 0xBE: return 0x37; // . >
            case 0xBF: return 0x38; // / ?
            case 0x2E: return 0x4C; // Delete
            case 0x27: return 0x4F; // Right
            case 0x25: return 0x50; // Left
            case 0x28: return 0x51; // Down
            case 0x26: return 0x52; // Up
            default: return -1;
        }
    }

    private byte[] buildReport() {
        synchronized (reportLock) {
            return buildReportLocked();
        }
    }

    private byte[] buildReportLocked() {
        byte[] report = new byte[8];
        report[0] = (byte) modifierByte();
        report[1] = 0;
        Iterator<Integer> iterator = pressedUsages.iterator();
        int i = 2;
        while (iterator.hasNext() && i < report.length) {
            report[i++] = (byte) (iterator.next() & 0xFF);
        }
        return report;
    }

    private void sendCurrentReport() {
        synchronized (reportLock) {
            sendCurrentReportLocked();
        }
    }

    private void sendCurrentReportLocked() {
        if (hidDevice == null || connectedHost == null || !hidRegistered || !hasBluetoothConnectPermission()) return;
        try {
            hidDevice.sendReport(connectedHost, 0, buildReportLocked());
        } catch (SecurityException ignored) {
        }
    }

    private void clearPressedKeys(boolean sendRelease) {
        synchronized (reportLock) {
            pressedUsages.clear();
            syntheticShiftTokens.clear();
            ctrlDown = false;
            shiftDown = false;
            altDown = false;
            guiDown = false;
            if (sendRelease) sendCurrentReportLocked();
        }
    }

    private final class KeyboardBridge {
        @JavascriptInterface
        public void keyDown(String token) {
            MainActivity.this.keyDown(token);
        }

        @JavascriptInterface
        public void keyUp(String token) {
            MainActivity.this.keyUp(token);
        }

        @JavascriptInterface
        public String getState() {
            return stateJson();
        }

        @JavascriptInterface
        public String getBondedDevices() {
            return bondedDevicesJson();
        }

        @JavascriptInterface
        public void connect(String address) {
            MainActivity.this.connectToAddress(address);
        }

        @JavascriptInterface
        public void makeDiscoverable() {
            MainActivity.this.makeDiscoverable();
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            MainActivity.this.openBluetoothSettings();
        }

        @JavascriptInterface
        public void restoreFullscreen() {
            runOnUiThread(MainActivity.this::configureCutoutAndImmersiveMode);
        }
    }
}
