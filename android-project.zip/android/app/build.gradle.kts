plugins {
    id("com.android.application")
}

android {
    namespace = "com.mozg4d.smartphonekeyboard"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mozg4d.smartphonekeyboard"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
